from app.config import settings
from app.core.elastic_client import create_elastic_index_if_not_exists


def main():
    mapping = {
        "mappings": {
            "properties": {
                "doc_id": {"type": "keyword"},
                "parent_doc_id": {"type": "keyword"},
                "title": {"type": "text"},
                "content": {"type": "text"},
                "source": {"type": "keyword"},
                "category": {"type": "keyword"},
                "vehicle_model": {"type": "keyword"},
                "severity": {"type": "keyword"},
                "status": {"type": "keyword"},
                "created_date": {"type": "date"},
                "content_vector": {
                    "type": "dense_vector",
                    "dims": settings.EMBEDDING_DIMENSIONS,
                    "index": True,
                    "similarity": "cosine",
                },
            }
        }
    }

    response = create_elastic_index_if_not_exists(mapping)
    print(response)


if __name__ == "__main__":
    main()
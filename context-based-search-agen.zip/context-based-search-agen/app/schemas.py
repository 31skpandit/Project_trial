from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


class ChatRequest(BaseModel):
    question: str = Field(..., description="User question")
    user_id: Optional[str] = "anonymous"
    conversation_id: Optional[str] = None


class SourceDocument(BaseModel):
    doc_id: Optional[str] = None
    title: Optional[str] = None
    content: Optional[str] = None
    source: Optional[str] = None
    score: Optional[float] = None
    metadata: Dict[str, Any] = {}


class ChatResponse(BaseModel):
    question: str
    route: str
    answer: str
    sources: List[Dict[str, Any]] = []
    metadata: Dict[str, Any] = {}


class IngestionRequest(BaseModel):
    document_id: str
    file_name: str
    content: str
    metadata: Dict[str, Any] = {}


class IngestionResponse(BaseModel):
    status: str
    document_id: str
    ai_search_chunks: List[str]
    elastic_chunks: List[str]


class RouteDecision(BaseModel):
    route: str
    reason: str


class ElasticQueryPlan(BaseModel):
    query_type: str
    search_text: str
    filters: Dict[str, Any] = {}
    aggregation_required: bool = False
    reason: Optional[str] = None
from fastapi import FastAPI, HTTPException
from app.schemas import ChatRequest, ChatResponse, IngestionRequest, IngestionResponse
from app.agents.orchestrator_agent import run_orchestrator
from app.core.cache_client import get_from_cache, set_to_cache
from app.core.logger import get_logger
from app.ingestion.document_processor import process_document_text
from app.ingestion.index_to_ai_search import index_text_to_ai_search
from app.ingestion.index_to_elastic import index_text_to_elastic


logger = get_logger(__name__)


app = FastAPI(
    title="Context Based Search Agent",
    description="Azure OpenAI + Azure AI Search + Elasticsearch Agentic RAG Backend",
    version="1.0.0",
)


@app.get("/")
def root():
    return {
        "status": "running",
        "service": "context-based-search-agent",
        "version": "1.0.0",
    }


@app.get("/health")
def health():
    return {
        "status": "healthy",
    }


@app.post("/chat", response_model=ChatResponse)
def chat(request: ChatRequest):
    try:
        cached = get_from_cache(request.question, "orchestrator")
        if cached:
            return ChatResponse(**cached)

        result = run_orchestrator(request.question)

        response = {
            "question": request.question,
            "route": result["route"],
            "answer": result["answer"],
            "sources": result.get("sources", []),
            "metadata": {
                **result.get("metadata", {}),
                "route_reason": result.get("route_reason"),
            },
        }

        set_to_cache(request.question, "orchestrator", response)

        return ChatResponse(**response)

    except Exception as ex:
        logger.exception("Chat request failed")
        raise HTTPException(status_code=500, detail=str(ex))


@app.post("/ingest", response_model=IngestionResponse)
def ingest(request: IngestionRequest):
    try:
        cleaned_text = process_document_text(request.content)

        ai_search_ids = index_text_to_ai_search(
            document_id=request.document_id,
            title=request.file_name,
            content=cleaned_text,
            metadata=request.metadata,
        )

        elastic_ids = index_text_to_elastic(
            document_id=request.document_id,
            title=request.file_name,
            content=cleaned_text,
            metadata=request.metadata,
        )

        return IngestionResponse(
            status="success",
            document_id=request.document_id,
            ai_search_chunks=ai_search_ids,
            elastic_chunks=elastic_ids,
        )

    except Exception as ex:
        logger.exception("Ingestion failed")
        raise HTTPException(status_code=500, detail=str(ex))
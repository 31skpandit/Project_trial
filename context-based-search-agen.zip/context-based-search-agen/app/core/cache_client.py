import hashlib
import json
from typing import Any, Dict, Optional
import redis
from app.config import settings


redis_client = None

if settings.CACHE_ENABLED:
    redis_client = redis.Redis(
        host=settings.REDIS_HOST,
        port=settings.REDIS_PORT,
        password=settings.REDIS_PASSWORD or None,
        decode_responses=True,
    )


def create_cache_key(question: str, route: str) -> str:
    raw = f"{route}:{question.lower().strip()}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def get_from_cache(question: str, route: str) -> Optional[Dict[str, Any]]:
    if not redis_client:
        return None

    value = redis_client.get(create_cache_key(question, route))
    if not value:
        return None

    return json.loads(value)


def set_to_cache(
    question: str,
    route: str,
    value: Dict[str, Any],
    ttl_seconds: int = 3600,
) -> bool:
    if not redis_client:
        return False

    redis_client.setex(
        create_cache_key(question, route),
        ttl_seconds,
        json.dumps(value),
    )
    return True
from typing import Any, Dict, List, Optional
from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient
from azure.search.documents.models import VectorizedQuery
from app.config import settings


search_client = SearchClient(
    endpoint=settings.AZURE_SEARCH_ENDPOINT,
    index_name=settings.AZURE_SEARCH_INDEX_NAME,
    credential=AzureKeyCredential(settings.AZURE_SEARCH_KEY),
)


def keyword_search_documents(search_text: str, top: int = 5) -> List[Dict[str, Any]]:
    results = search_client.search(
        search_text=search_text,
        top=top,
    )
    return [dict(result) for result in results]


def vector_search_documents(
    query_vector: List[float],
    vector_field: str = "content_vector",
    top: int = 5,
    select: Optional[List[str]] = None,
) -> List[Dict[str, Any]]:
    vector_query = VectorizedQuery(
        vector=query_vector,
        k_nearest_neighbors=top,
        fields=vector_field,
    )

    results = search_client.search(
        search_text=None,
        vector_queries=[vector_query],
        select=select or ["id", "doc_id", "parent_doc_id", "title", "content", "source", "category"],
        top=top,
    )

    return [dict(result) for result in results]


def upload_documents_to_ai_search(documents: List[Dict[str, Any]]) -> Any:
    return search_client.upload_documents(documents=documents)
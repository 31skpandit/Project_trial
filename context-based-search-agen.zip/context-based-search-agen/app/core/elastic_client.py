from typing import Dict, Any
from elasticsearch import Elasticsearch
from app.config import settings


elastic_client = Elasticsearch(
    cloud_id=settings.ELASTIC_CLOUD_ID,
    api_key=settings.ELASTIC_API_KEY,
)


def ping_elastic() -> bool:
    return elastic_client.ping()


def search_elastic(query_body: Dict[str, Any]) -> Dict[str, Any]:
    return elastic_client.search(
        index=settings.ELASTIC_INDEX_NAME,
        body=query_body,
    )


def index_document_to_elastic(document_id: str, document: Dict[str, Any]) -> Dict[str, Any]:
    return elastic_client.index(
        index=settings.ELASTIC_INDEX_NAME,
        id=document_id,
        document=document,
    )


def create_elastic_index_if_not_exists(mapping: Dict[str, Any]) -> Dict[str, Any]:
    if elastic_client.indices.exists(index=settings.ELASTIC_INDEX_NAME):
        return {"status": "exists", "index": settings.ELASTIC_INDEX_NAME}

    response = elastic_client.indices.create(
        index=settings.ELASTIC_INDEX_NAME,
        body=mapping,
    )

    return {
        "status": "created",
        "index": settings.ELASTIC_INDEX_NAME,
        "response": response,
    }
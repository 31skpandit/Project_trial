def process_document_text(raw_text: str) -> str:
    """
    Starter text processor.
    Later replace/enrich this with Azure AI Document Intelligence for PDFs, scans, forms.
    """
    if not raw_text:
        return ""

    text = raw_text.replace("\x00", " ")
    text = text.replace("\r", "\n")
    text = "\n".join(line.strip() for line in text.splitlines() if line.strip())
    return text
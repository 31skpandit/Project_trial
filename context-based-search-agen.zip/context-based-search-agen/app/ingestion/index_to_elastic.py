from typing import Any, Dict, List
from app.core.azure_openai_client import get_embedding
from app.core.elastic_client import index_document_to_elastic
from app.ingestion.chunker import chunk_text


def index_text_to_elastic(
    document_id: str,
    title: str,
    content: str,
    metadata: Dict[str, Any],
) -> Listchunks = chunk_text(content)

    indexed_ids = []

    for idx, chunk in enumerate(chunks):
        chunk_id = f"{document_id}-chunk-{idx}"

        document = {
            "doc_id": chunk_id,
            "parent_doc_id": document_id,
            "title": title,
            "content": chunk,
            "content_vector": get_embedding(chunk),
            "source": metadata.get("source", ""),
            "category": metadata.get("category", ""),
            "vehicle_model": metadata.get("vehicle_model", ""),
            "severity": metadata.get("severity", ""),
            "status": metadata.get("status", ""),
            "created_date": metadata.get("created_date", None),
        }

        index_document_to_elastic(chunk_id, document)
        indexed_ids.append(chunk_id)

    return indexed_ids
from typing import Any, Dict, List
from app.core.azure_openai_client import get_embedding
from app.core.azure_search_client import upload_documents_to_ai_search
from app.ingestion.chunker import chunk_text


def index_text_to_ai_search(
    document_id: str,
    title: str,
    content: str,
    metadata: Dict[str, Any],
) -> Listchunks = chunk_text(content)

    documents = []

    for idx, chunk in enumerate(chunks):
        chunk_id = f"{document_id}-chunk-{idx}"

        documents.append({
            "id": chunk_id,
            "doc_id": chunk_id,
            "parent_doc_id": document_id,
            "title": title,
            "content": chunk,
            "content_vector": get_embedding(chunk),
            "source": metadata.get("source", ""),
            "category": metadata.get("category", ""),
        })

    if documents:
        upload_documents_to_ai_search(documents)

    return [doc["id"] for doc in documents]
from typing import Any, Dict, List
from app.core.azure_openai_client import get_chat_completion
from app.prompts.summarizer_prompt import SUMMARIZER_PROMPT
from app.retrieval.elastic_retriever import elastic_retrieve


def extract_elastic_sources(elastic_results: Dict[str, Any]) -> List[Dict[str, Any]]:
    sources = []

    hits = elastic_results.get("hits", {}).get("hits", [])

    for hit in hits:
        src = hit.get("_source", {})
        sources.append({
            "score": hit.get("_score"),
            "doc_id": src.get("doc_id"),
            "parent_doc_id": src.get("parent_doc_id"),
            "title": src.get("title"),
            "content": src.get("content"),
            "source": src.get("source"),
            "category": src.get("category"),
            "vehicle_model": src.get("vehicle_model"),
            "severity": src.get("severity"),
            "status": src.get("status"),
            "created_date": src.get("created_date"),
        })

    return sources


def extract_aggregations(elastic_results: Dict[str, Any]) -> Dict[str, Any]:
    return elastic_results.get("aggregations", elastic_results.get("aggs", {}))


def run_query_agent(question: str) -> Dict[str, Any]:
    retrieval = elastic_retrieve(question)

    plan = retrieval["plan"]
    raw_results = retrieval["results"]

    sources = extract_elastic_sources(raw_results)
    aggregations = extract_aggregations(raw_results)

    messages = [
        {"role": "system", "content": SUMMARIZER_PROMPT},
        {
            "role": "user",
            "content": f"""
User Question:
{question}

Query Plan:
{plan}

Elasticsearch Sources:
{sources}

Aggregations:
{aggregations}
"""
        },
    ]

    answer = get_chat_completion(messages)

    return {
        "answer": answer,
        "sources": sources,
        "metadata": {
            "retriever": "elasticsearch",
            "query_plan": plan,
            "aggregations": aggregations,
        },
    }
def basic_input_guardrail(question: str) -> None:
    """
    Basic starter guardrail.
    In production, integrate Azure AI Content Safety and prompt-injection checks.
    """
    blocked_phrases = [
        "ignore previous instructions",
        "reveal system prompt",
        "show hidden prompt",
        "delete all data",
        "drop index",
    ]

    question_lower = question.lower()

    for phrase in blocked_phrases:
        if phrase in question_lower:
            raise ValueError("Question blocked by safety guardrail.")
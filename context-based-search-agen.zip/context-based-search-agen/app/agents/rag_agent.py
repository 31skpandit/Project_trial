from typing import Any, Dict
from app.core.azure_openai_client import get_chat_completion
from app.prompts.summarizer_prompt import SUMMARIZER_PROMPT
from app.retrieval.azure_ai_search_retriever import retrieve_from_ai_search


def run_rag_agent(question: str) -> Dict[str, Any]:
    documents = retrieve_from_ai_search(question, top=5)

    messages = [
        {"role": "system", "content": SUMMARIZER_PROMPT},
        {
            "role": "user",
            "content": f"""
User Question:
{question}

Retrieved Context:
{documents}
"""
        },
    ]

    answer = get_chat_completion(messages)

    return {
        "answer": answer,
        "sources": documents,
        "metadata": {
            "retriever": "azure_ai_search",
            "document_count": len(documents),
        },
    }
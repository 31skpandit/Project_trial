from typing import Any, Dict
from app.agents.safety_agent import basic_input_guardrail
from app.agents.rag_agent import run_rag_agent
from app.agents.query_agent import run_query_agent
from app.core.azure_openai_client import get_chat_completion
from app.prompts.orchestrator_prompt import ORCHESTRATOR_SYSTEM_PROMPT
from app.utils.json_utils import extract_json_object


def classify_route(question: str) -> Dict[str, Any]:
    messages = [
        {"role": "system", "content": ORCHESTRATOR_SYSTEM_PROMPT},
        {"role": "user", "content": question},
    ]

    response = get_chat_completion(messages)
    return extract_json_object(response)


def run_orchestrator(question: str) -> Dict[str, Any]:
    basic_input_guardrail(question)

    route_decision = classify_route(question)
    route = route_decision.get("route", "general")

    if route == "rag_agent":
        result = run_rag_agent(question)

    elif route == "query_agent":
        result = run_query_agent(question)

    else:
        messages = [
            {
                "role": "system",
                "content": "You are a helpful enterprise assistant. Keep answers concise and practical.",
            },
            {"role": "user", "content": question},
        ]
        answer = get_chat_completion(messages)
        result = {
            "answer": answer,
            "sources": [],
            "metadata": {
                "retriever": "none",
            },
        }

    return {
        "route": route,
        "route_reason": route_decision.get("reason"),
        "answer": result["answer"],
        "sources": result.get("sources", []),
        "metadata": result.get("metadata", {}),
    }
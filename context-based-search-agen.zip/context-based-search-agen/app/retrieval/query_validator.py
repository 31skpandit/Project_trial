from typing import Any, Dict


ALLOWED_TOP_LEVEL_KEYS = {
    "query",
    "size",
    "from",
    "sort",
    "aggs",
    "aggregations",
    "_source",
    "knn",
}

BLOCKED_TOKENS = {
    "script",
    "script_score",
    "painless",
    "delete",
    "update",
    "runtime_mappings",
    "_delete_by_query",
}


def validate_elastic_query(query_body: Dict[str, Any]) -> bool:
    if not isinstance(query_body, dict):
        return False

    for key in query_body.keys():
        if key not in ALLOWED_TOP_LEVEL_KEYS:
            return False

    query_string = str(query_body).lower()

    for blocked in BLOCKED_TOKENS:
        if blocked in query_string:
            return False

    if "size" in query_body and query_body["size"] > 10:
        query_body["size"] = 10

    return True
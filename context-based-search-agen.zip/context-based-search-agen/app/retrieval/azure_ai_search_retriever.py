from typing import Any, Dict, List
from app.core.azure_openai_client import get_embedding
from app.core.azure_search_client import keyword_search_documents, vector_search_documents


def retrieve_from_ai_search(question: str, top: int = 5) -> List[Dict[str, Any]]:
    """
    Hybrid-lite approach:
    1. Run keyword search.
    2. Run vector search.
    3. Merge unique docs.
    """
    keyword_results = keyword_search_documents(question, top=top)
    query_vector = get_embedding(question)
    vector_results = vector_search_documents(query_vector=query_vector, top=top)

    merged = {}
    for item in keyword_results + vector_results:
        doc_id = item.get("id") or item.get("doc_id") or item.get("parent_doc_id")
        if doc_id and doc_id not in merged:
            merged[doc_id] = {
                "doc_id": item.get("doc_id") or item.get("id"),
                "title": item.get("title"),
                "content": item.get("content"),
                "source": item.get("source"),
                "category": item.get("category"),
                "score": item.get("@search.score"),
            }

    return list(merged.values())[:top]
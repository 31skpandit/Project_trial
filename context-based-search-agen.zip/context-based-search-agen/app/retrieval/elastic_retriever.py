from typing import Any, Dict
from app.core.azure_openai_client import get_chat_completion, get_embedding
from app.core.elastic_client import search_elastic
from app.prompts.query_agent_prompt import QUERY_PLANNER_PROMPT, ELASTIC_DSL_GENERATOR_PROMPT
from app.retrieval.query_validator import validate_elastic_query
from app.utils.json_utils import extract_json_object


def plan_elastic_query(question: str) -> Dict[str, Any]:
    messages = [
        {"role": "system", "content": QUERY_PLANNER_PROMPT},
        {"role": "user", "content": question},
    ]

    response = get_chat_completion(messages)
    return extract_json_object(response)


def generate_elastic_dsl(question: str) -> Dict[str, Any]:
    messages = [
        {"role": "system", "content": ELASTIC_DSL_GENERATOR_PROMPT},
        {"role": "user", "content": question},
    ]

    response = get_chat_completion(messages)
    query_body = extract_json_object(response)

    if not validate_elastic_query(query_body):
        raise ValueError("Unsafe Elasticsearch query generated.")

    return query_body


def keyword_search(search_text: str) -> Dict[str, Any]:
    query_body = {
        "size": 10,
        "query": {
            "multi_match": {
                "query": search_text,
                "fields": ["title^3", "content", "category", "vehicle_model", "severity", "status"]
            }
        }
    }

    return search_elastic(query_body)


def vector_search(question: str, top_k: int = 5) -> Dict[str, Any]:
    query_vector = get_embedding(question)

    query_body = {
        "knn": {
            "field": "content_vector",
            "query_vector": query_vector,
            "k": top_k,
            "num_candidates": 100
        },
        "_source": [
            "doc_id",
            "parent_doc_id",
            "title",
            "content",
            "source",
            "category",
            "vehicle_model",
            "severity",
            "status",
            "created_date"
        ]
    }

    return search_elastic(query_body)


def elastic_retrieve(question: str) -> Dict[str, Any]:
    plan = plan_elastic_query(question)
    query_type = plan.get("query_type", "keyword_search")

    if query_type == "vector_search":
        results = vector_search(question)

    elif query_type == "keyword_search":
        results = keyword_search(plan.get("search_text", question))

    else:
        dsl = generate_elastic_dsl(question)
        results = search_elastic(dsl)

    return {
        "plan": plan,
        "results": results,
    }
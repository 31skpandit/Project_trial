import azure.functions as func
from app.main import app as fastapi_app
from app.core.logger import get_logger

logger = get_logger(__name__)

try:
    app = func.AsgiFunctionApp(
        app=fastapi_app,
        http_auth_level=func.AuthLevel.FUNCTION,
    )
    logger.info("Azure Function app initialized successfully.")
except Exception as e:
    logger.error(f"Error initializing Azure Function app: {e}")
    raise
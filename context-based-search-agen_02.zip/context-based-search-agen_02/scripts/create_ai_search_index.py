from azure.core.credentials import AzureKeyCredential
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import (
    SearchIndex,
    SimpleField,
    SearchableField,
    SearchField,
    SearchFieldDataType,
    VectorSearch,
    HnswAlgorithmConfiguration,
    VectorSearchProfile,
)
from app.config import settings
from app.core.logger import get_logger

logger = get_logger(__name__)

def main():
    """
    Create an Azure AI Search index with vector search capabilities.

    Raises:
        Exception: If index creation fails.
    """
    try:
        # Initialize the SearchIndexClient
        index_client = SearchIndexClient(
            endpoint=settings.AZURE_SEARCH_ENDPOINT,
            credential=AzureKeyCredential(settings.AZURE_SEARCH_KEY),
        )
        logger.info("SearchIndexClient initialized successfully.")

        # Define the fields for the index
        fields = [
            SimpleField(name="id", type=SearchFieldDataType.String, key=True),
            SimpleField(name="doc_id", type=SearchFieldDataType.String, filterable=True),
            SimpleField(name="parent_doc_id", type=SearchFieldDataType.String, filterable=True),
            SearchableField(name="title", type=SearchFieldDataType.String),
            SearchableField(name="content", type=SearchFieldDataType.String),
            SimpleField(name="source", type=SearchFieldDataType.String, filterable=True),
            SimpleField(name="category", type=SearchFieldDataType.String, filterable=True),
            SearchField(
                name="content_vector",
                type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
                searchable=True,
                vector_search_dimensions=settings.EMBEDDING_DIMENSIONS,
                vector_search_profile_name="vector-profile",
            ),
        ]

        # Define the vector search configuration
        vector_search = VectorSearch(
            algorithms=[
                HnswAlgorithmConfiguration(name="hnsw-config")
            ],
            profiles=[
                VectorSearchProfile(
                    name="vector-profile",
                    algorithm_configuration_name="hnsw-config",
                )
            ],
        )

        # Create the index
        index = SearchIndex(
            name=settings.AZURE_SEARCH_INDEX_NAME,
            fields=fields,
            vector_search=vector_search,
        )

        logger.info(f"Creating index: {settings.AZURE_SEARCH_INDEX_NAME}")
        result = index_client.create_index(index)
        logger.info(f"Index created successfully: {result}")

    except Exception as e:
        logger.error(f"Error creating AI Search index: {e}")
        raise

if __name__ == "__main__":
    main()
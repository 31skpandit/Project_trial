from app.config import settings
from app.core.elastic_client import create_elastic_index_if_not_exists
from app.core.logger import get_logger

logger = get_logger(__name__)

def main():
    """
    Create an Elasticsearch index with the specified mapping.

    Raises:
        Exception: If index creation fails.
    """
    try:
        # Define the index mapping
        mapping = {
            "mappings": {
                "properties": {
                    "doc_id": {"type": "keyword"},
                    "parent_doc_id": {"type": "keyword"},
                    "title": {"type": "text"},
                    "content": {"type": "text"},
                    "source": {"type": "keyword"},
                    "category": {"type": "keyword"},
                    "vehicle_model": {"type": "keyword"},
                    "severity": {"type": "keyword"},
                    "status": {"type": "keyword"},
                    "created_date": {"type": "date"},
                    "content_vector": {
                        "type": "dense_vector",
                        "dims": settings.EMBEDDING_DIMENSIONS,
                        "index": True,
                        "similarity": "cosine",
                    },
                }
            }
        }

        # Create the index if it does not exist
        logger.info(f"Creating Elasticsearch index: {settings.ELASTIC_INDEX_NAME}")
        response = create_elastic_index_if_not_exists(mapping)
        logger.info(f"Elasticsearch index creation response: {response}")
    except Exception as e:
        logger.error(f"Error creating Elasticsearch index: {e}")
        raise

if __name__ == "__main__":
    main()
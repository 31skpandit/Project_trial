# Context Based Search Agent

Enterprise Agentic RAG backend using:

- Azure OpenAI
- Azure AI Search
- Elasticsearch
- FastAPI
- Optional Azure Functions wrapper

## Architecture

User / Bot / Power Apps / MDM UI
→ FastAPI Backend
→ Orchestrator Agent
→ RAG Agent or Query Agent
→ Azure AI Search or Elasticsearch
→ Azure OpenAI summarization
→ Final answer with sources

## Setup

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
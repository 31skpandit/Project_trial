from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field

class ChatRequest(BaseModel):
    """
    Schema for chat request payload.

    Attributes:
        question (str): The user question.
        user_id (Optional[str]): The ID of the user (default: "anonymous").
        conversation_id (Optional[str]): The conversation ID.
    """
    question: str = Field(..., description="User question")
    user_id: Optional[str] = "anonymous"
    conversation_id: Optional[str] = None

class SourceDocument(BaseModel):
    """
    Schema for a source document.

    Attributes:
        doc_id (Optional[str]): The document ID.
        title (Optional[str]): The title of the document.
        content (Optional[str]): The content of the document.
        source (Optional[str]): The source of the document.
        score (Optional[float]): The relevance score of the document.
        metadata (Dict[str, Any]): Additional metadata for the document.
    """
    doc_id: Optional[str] = None
    title: Optional[str] = None
    content: Optional[str] = None
    source: Optional[str] = None
    score: Optional[float] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)

class ChatResponse(BaseModel):
    """
    Schema for chat response payload.

    Attributes:
        question (str): The user question.
        route (str): The route taken by the orchestrator.
        answer (str): The generated answer.
        sources (List[Dict[str, Any]]): List of source documents.
        metadata (Dict[str, Any]): Additional metadata for the response.
    """
    question: str
    route: str
    answer: str
    sources: List[Dict[str, Any]] = Field(default_factory=list)
    metadata: Dict[str, Any] = Field(default_factory=dict)

class IngestionRequest(BaseModel):
    """
    Schema for ingestion request payload.

    Attributes:
        document_id (str): The ID of the document.
        file_name (str): The name of the file.
        content (str): The content of the document.
        metadata (Dict[str, Any]): Additional metadata for the document.
    """
    document_id: str
    file_name: str
    content: str
    metadata: Dict[str, Any] = Field(default_factory=dict)

class IngestionResponse(BaseModel):
    """
    Schema for ingestion response payload.

    Attributes:
        status (str): The status of the ingestion process.
        document_id (str): The ID of the ingested document.
        ai_search_chunks (List[str]): List of AI search chunks.
        elastic_chunks (List[str]): List of Elasticsearch chunks.
    """
    status: str
    document_id: str
    ai_search_chunks: List[str]
    elastic_chunks: List[str]

class RouteDecision(BaseModel):
    """
    Schema for route decision.

    Attributes:
        route (str): The selected route.
        reason (str): The reason for the route selection.
    """
    route: str
    reason: str

class ElasticQueryPlan(BaseModel):
    """
    Schema for Elasticsearch query plan.

    Attributes:
        query_type (str): The type of query.
        search_text (str): The search text.
        filters (Dict[str, Any]): Filters for the query.
    """
    query_type: str
    search_text: str
    filters: Dict[str, Any] = Field(default_factory=dict)
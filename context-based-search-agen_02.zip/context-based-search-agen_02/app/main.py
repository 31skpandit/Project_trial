from fastapi import FastAPI, HTTPException
from app.schemas import ChatRequest, ChatResponse, IngestionRequest, IngestionResponse
from app.agents.orchestrator_agent import run_orchestrator
from app.core.cache_client import get_from_cache, set_to_cache
from app.core.logger import get_logger
from app.ingestion.document_processor import process_document_text
from app.ingestion.index_to_ai_search import index_text_to_ai_search
from app.ingestion.index_to_elastic import index_text_to_elastic

logger = get_logger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="Context Based Search Agent",
    description="Azure OpenAI + Azure AI Search + Elasticsearch Agentic RAG Backend",
    version="1.0.0",
)

@app.get("/")
def root():
    """
    Root endpoint to check service status.

    Returns:
        dict: Service status and version.
    """
    logger.info("Root endpoint accessed.")
    return {
        "status": "running",
        "service": "context-based-search-agent",
        "version": "1.0.0",
    }

@app.get("/health")
def health():
    """
    Health check endpoint.

    Returns:
        dict: Health status.
    """
    logger.info("Health endpoint accessed.")
    return {
        "status": "healthy",
    }

@app.post("/chat", response_model=ChatResponse)
def chat(request: ChatRequest):
    """
    Chat endpoint to handle user questions.

    Args:
        request (ChatRequest): The chat request containing the user question.

    Returns:
        ChatResponse: The response containing the answer and sources.
    """
    try:
        logger.info(f"Received chat request: {request.question}")

        # Check cache for existing response
        cached = get_from_cache(request.question, "orchestrator")
        if cached:
            logger.info("Cache hit for question.")
            return ChatResponse(**cached)

        # Run orchestrator to get the response
        result = run_orchestrator(request.question)

        response = {
            "question": request.question,
            "route": result.get("route", "unknown"),
            "answer": result.get("answer", "No answer available."),
            "sources": result.get("sources", []),
        }

        # Cache the response
        set_to_cache(request.question, "orchestrator", response)

        return ChatResponse(**response)
    except Exception as e:
        logger.error(f"Error in /chat endpoint: {e}")
        raise HTTPException(status_code=500, detail="Internal server error.")
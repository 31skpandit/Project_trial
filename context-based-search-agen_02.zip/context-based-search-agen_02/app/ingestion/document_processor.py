def process_document_text(raw_text: str) -> str:
    """
    Process raw document text for indexing.

    Args:
        raw_text (str): The raw text of the document.

    Returns:
        str: Processed text.
    """
    if not raw_text:
        return ""

    try:
        text = raw_text.replace("\x00", " ")
        text = text.replace("\r", "\n")
        text = "\n".join(line.strip() for line in text.splitlines() if line.strip())
        return text
    except Exception as e:
        print(f"Error in process_document_text: {e}")
        return ""
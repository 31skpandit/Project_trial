from typing import List

def chunk_text(text: str, chunk_size: int = 1200, overlap: int = 200) -> List[str]:
    """
    Chunk text into smaller parts with overlap.

    Args:
        text (str): The input text to chunk.
        chunk_size (int): The size of each chunk.
        overlap (int): The overlap between consecutive chunks.

    Returns:
        List[str]: List of text chunks.
    """
    if not text:
        return []

    chunks = []
    start = 0
    text_length = len(text)

    while start < text_length:
        end = min(start + chunk_size, text_length)
        chunk = text[start:end].strip()

        if chunk:
            chunks.append(chunk)

        if end == text_length:
            break

        start = end - overlap

    return chunks
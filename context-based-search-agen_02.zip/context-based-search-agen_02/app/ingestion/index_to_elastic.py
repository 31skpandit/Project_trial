from app.core.elastic_client import index_document_to_elastic
from app.core.logger import get_logger

logger = get_logger(__name__)

def index_text_to_elastic(doc_id: str, text: str) -> bool:
    """
    Index text into Elasticsearch.

    Args:
        doc_id (str): The document ID.
        text (str): The text to index.

    Returns:
        bool: True if indexing is successful, False otherwise.
    """
    try:
        document = {
            "id": doc_id,
            "content": text,
        }

        result = index_document_to_elastic(doc_id, document)
        logger.info(f"Indexed document {doc_id} to Elasticsearch: {result}")
        return True
    except Exception as e:
        logger.error(f"Error indexing document {doc_id} to Elasticsearch: {e}")
        return False
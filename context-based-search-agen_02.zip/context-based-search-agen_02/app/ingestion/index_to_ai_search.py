from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient
from app.config import settings
from app.core.logger import get_logger

logger = get_logger(__name__)

def index_text_to_ai_search(doc_id: str, text: str) -> bool:
    """
    Index text into Azure AI Search.

    Args:
        doc_id (str): The document ID.
        text (str): The text to index.

    Returns:
        bool: True if indexing is successful, False otherwise.
    """
    try:
        search_client = SearchClient(
            endpoint=settings.AZURE_SEARCH_ENDPOINT,
            index_name=settings.AZURE_SEARCH_INDEX_NAME,
            credential=AzureKeyCredential(settings.AZURE_SEARCH_KEY),
        )

        document = {
            "id": doc_id,
            "content": text,
        }

        result = search_client.upload_documents(documents=[document])
        logger.info(f"Indexed document {doc_id} to AI Search: {result}")
        return True
    except Exception as e:
        logger.error(f"Error indexing document {doc_id} to AI Search: {e}")
        return False
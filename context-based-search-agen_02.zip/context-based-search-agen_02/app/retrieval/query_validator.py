from typing import Any, Dict
from app.core.logger import get_logger

logger = get_logger(__name__)

# Allowed top-level keys in Elasticsearch queries
ALLOWED_TOP_LEVEL_KEYS = {
    "query",
    "size",
    "from",
    "sort",
    "aggs",
    "aggregations",
    "_source",
    "knn",
}

# Blocked tokens in Elasticsearch queries
BLOCKED_TOKENS = {
    "script",
    "script_score",
    "painless",
    "delete",
    "update",
    "runtime_mappings",
    "_delete_by_query",
}

def validate_elastic_query(query_body: Dict[str, Any], max_size: int = 10) -> bool:
    """
    Validate an Elasticsearch query to ensure it is safe and adheres to constraints.

    Args:
        query_body (Dict[str, Any]): The query body to validate.
        max_size (int): Maximum allowed size for the query.

    Returns:
        bool: True if the query is valid, False otherwise.
    """
    if not isinstance(query_body, dict):
        logger.error("Query body is not a dictionary.")
        return False

    # Check for disallowed top-level keys
    for key in query_body.keys():
        if key not in ALLOWED_TOP_LEVEL_KEYS:
            logger.error(f"Disallowed key in query: {key}")
            return False

    # Check for blocked tokens in the query
    query_string = str(query_body).lower()
    for blocked in BLOCKED_TOKENS:
        if blocked in query_string:
            logger.error(f"Blocked token found in query: {blocked}")
            return False

    # Enforce size limit
    if "size" in query_body and query_body["size"] > max_size:
        logger.warning(f"Query size exceeds limit. Reducing size to {max_size}.")
        query_body["size"] = max_size

    return True
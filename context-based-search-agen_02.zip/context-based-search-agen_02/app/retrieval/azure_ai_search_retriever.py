from typing import Any, Dict, List
from app.core.azure_openai_client import get_embedding
from app.core.azure_search_client import keyword_search_documents, vector_search_documents
from app.core.logger import get_logger

logger = get_logger(__name__)

def retrieve_from_ai_search(question: str, top: int = 5) -> List[Dict[str, Any]]:
    """
    Retrieve documents from Azure AI Search using a hybrid approach.

    Args:
        question (str): The user question.
        top (int): The number of top results to return.

    Returns:
        List[Dict[str, Any]]: List of retrieved documents.
    """
    try:
        # Perform keyword search
        logger.info(f"Performing keyword search for question: {question}")
        keyword_results = keyword_search_documents(question, top=top)

        # Generate query vector using embeddings
        logger.info("Generating query vector using embeddings.")
        query_vector = get_embedding(question)

        # Perform vector search
        logger.info("Performing vector search.")
        vector_results = vector_search_documents(query_vector=query_vector, top=top)

        # Merge results
        logger.info("Merging keyword and vector search results.")
        merged = {}
        for item in keyword_results + vector_results:
            doc_id = item.get("id") or item.get("doc_id") or item.get("parent_doc_id")
            if doc_id and doc_id not in merged:
                merged[doc_id] = {
                    "doc_id": item.get("doc_id") or item.get("id"),
                    "title": item.get("title"),
                    "content": item.get("content"),
                    "source": item.get("source"),
                    "category": item.get("category"),
                    "score": item.get("@search.score"),
                }

        return list(merged.values())[:top]
    except Exception as e:
        logger.error(f"Error in retrieve_from_ai_search: {e}")
        return []
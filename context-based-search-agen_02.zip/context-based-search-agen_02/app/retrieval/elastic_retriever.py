from typing import Any, Dict
from app.core.azure_openai_client import get_chat_completion, get_embedding
from app.core.elastic_client import search_elastic
from app.prompts.query_agent_prompt import QUERY_PLANNER_PROMPT, ELASTIC_DSL_GENERATOR_PROMPT
from app.retrieval.query_validator import validate_elastic_query
from app.utils.json_utils import extract_json_object
from app.core.logger import get_logger

logger = get_logger(__name__)

def plan_elastic_query(question: str) -> Dict[str, Any]:
    """
    Plan an Elasticsearch query based on the user question.

    Args:
        question (str): The user question.

    Returns:
        Dict[str, Any]: The planned query.
    """
    try:
        messages = [
            {"role": "system", "content": QUERY_PLANNER_PROMPT},
            {"role": "user", "content": question},
        ]

        response = get_chat_completion(messages)
        return extract_json_object(response)
    except Exception as e:
        logger.error(f"Error in plan_elastic_query: {e}")
        return {}

def generate_elastic_dsl(question: str) -> Dict[str, Any]:
    """
    Generate an Elasticsearch DSL query from the user question.

    Args:
        question (str): The user question.

    Returns:
        Dict[str, Any]: The generated DSL query.

    Raises:
        ValueError: If the generated query is unsafe.
    """
    try:
        messages = [
            {"role": "system", "content": ELASTIC_DSL_GENERATOR_PROMPT},
            {"role": "user", "content": question},
        ]

        response = get_chat_completion(messages)
        query_body = extract_json_object(response)

        if not validate_elastic_query(query_body):
            logger.error("Unsafe Elasticsearch query generated.")
            raise ValueError("Unsafe Elasticsearch query generated.")

        return query_body
    except Exception as e:
        logger.error(f"Error in generate_elastic_dsl: {e}")
        return {}

def keyword_search(search_text: str) -> Dict[str, Any]:
    """
    Perform a keyword search on Elasticsearch.

    Args:
        search_text (str): The text to search for.

    Returns:
        Dict[str, Any]: The search results.
    """
    try:
        query_body = {
            "size": 10,
            "query": {
                "multi_match": {
                    "query": search_text,
                    "fields": ["title^3", "content", "category", "vehicle_model", "severity", "status"]
                }
            }
        }

        return search_elastic(query_body)
    except Exception as e:
        logger.error(f"Error in keyword_search: {e}")
        return {}

def vector_search(question: str, top_k: int = 5) -> Dict[str, Any]:
    """
    Perform a vector search on Elasticsearch.

    Args:
        question (str): The user question.
        top_k (int): The number of top results to return.

    Returns:
        Dict[str, Any]: The search results.
    """
    try:
        query_vector = get_embedding(question)
        if not query_vector:
            logger.error("Failed to generate query vector.")
            return {}

        query_body = {
            "size": top_k,
            "query": {
                "knn": {
                    "field": "embedding",
                    "query_vector": query_vector,
                    "k": top_k,
                    "num_candidates": 100
                }
            }
        }

        return search_elastic(query_body)
    except Exception as e:
        logger.error(f"Error in vector_search: {e}")
        return {}
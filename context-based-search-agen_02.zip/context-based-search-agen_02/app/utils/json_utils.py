from typing import Any, Dict
import json
import re

def extract_json_object(text: str) -> Dict[str, Any]:
    """
    Extracts the first JSON object from a string.

    Args:
        text (str): The input string containing JSON.

    Returns:
        Dict[str, Any]: The extracted JSON object.

    Raises:
        ValueError: If the input text is empty or JSON parsing fails.
    """
    if not text:
        raise ValueError("Empty JSON response")

    cleaned = text.strip()

    if cleaned.startswith("```"):
        cleaned = re.sub(r"^```json", "", cleaned, flags=re.IGNORECASE).strip()
        cleaned = re.sub(r"^```", "", cleaned).strip()
        cleaned = re.sub(r"```$", "", cleaned).strip()

    try:
        return json.loads(cleaned)
    except json.JSONDecodeError as e:
        match = re.search(r"\{.*\}", cleaned, re.DOTALL)
        if match:
            try:
                return json.loads(match.group(0))
            except json.JSONDecodeError as inner_e:
                raise ValueError(f"Error parsing JSON: {inner_e}") from inner_e
        raise ValueError(f"Error parsing JSON: {e}") from e
from typing import Any, Dict
from app.agents.safety_agent import basic_input_guardrail
from app.agents.rag_agent import run_rag_agent
from app.agents.query_agent import run_query_agent
from app.core.azure_openai_client import get_chat_completion
from app.prompts.orchestrator_prompt import ORCHESTRATOR_SYSTEM_PROMPT
from app.utils.json_utils import extract_json_object

def classify_route(question: str) -> Dict[str, Any]:
    """
    Classify the route for the given question.

    Args:
        question (str): The user question.

    Returns:
        Dict[str, Any]: The classification result.
    """
    messages = [
        {"role": "system", "content": ORCHESTRATOR_SYSTEM_PROMPT},
        {"role": "user", "content": question},
    ]

    try:
        response = get_chat_completion(messages)
        return extract_json_object(response)
    except Exception as e:
        print(f"Error in classify_route: {e}")
        return {}

def run_orchestrator(question: str) -> Dict[str, Any]:
    """
    Run the orchestrator to determine the route and execute the appropriate agent.

    Args:
        question (str): The user question.

    Returns:
        Dict[str, Any]: The response from the selected agent.
    """
    try:
        basic_input_guardrail(question)
        route = classify_route(question)

        if route.get("agent") == "rag":
            return run_rag_agent(question)
        elif route.get("agent") == "query":
            return run_query_agent(question)
        else:
            return {"error": "Unknown route"}
    except Exception as e:
        print(f"Error in run_orchestrator: {e}")
        return {"error": str(e)}
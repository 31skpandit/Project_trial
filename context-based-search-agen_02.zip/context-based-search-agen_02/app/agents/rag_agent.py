from typing import Any, Dict
from app.core.azure_openai_client import get_chat_completion
from app.prompts.summarizer_prompt import SUMMARIZER_PROMPT
from app.retrieval.azure_ai_search_retriever import retrieve_from_ai_search

def run_rag_agent(question: str) -> Dict[str, Any]:
    """
    Run the RAG agent to retrieve and summarize data.

    Args:
        question (str): The user question.

    Returns:
        Dict[str, Any]: The summarized response.
    """
    try:
        documents = retrieve_from_ai_search(question, top=5)

        messages = [
            {"role": "system", "content": SUMMARIZER_PROMPT},
            {
                "role": "user",
                "content": f"""
User Question:
{question}

Retrieved Context:
{documents}
"""
            },
        ]

        answer = get_chat_completion(messages)
        return {"answer": answer, "documents": documents}
    except Exception as e:
        print(f"Error in run_rag_agent: {e}")
        return {"error": str(e)}
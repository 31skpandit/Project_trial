from typing import Any, Dict, List
from app.core.azure_openai_client import get_chat_completion
from app.prompts.summarizer_prompt import SUMMARIZER_PROMPT
from app.retrieval.elastic_retriever import elastic_retrieve

def extract_elastic_sources(elastic_results: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Extract sources from Elasticsearch results.

    Args:
        elastic_results (Dict[str, Any]): Elasticsearch results.

    Returns:
        List[Dict[str, Any]]: List of source documents.
    """
    sources = []
    hits = elastic_results.get("hits", {}).get("hits", [])

    for hit in hits:
        source = hit.get("_source", {})
        if source:
            sources.append(source)

    return sources

def extract_aggregations(elastic_results: Dict[str, Any]) -> Dict[str, Any]:
    """
    Extract aggregations from Elasticsearch results.

    Args:
        elastic_results (Dict[str, Any]): Elasticsearch results.

    Returns:
        Dict[str, Any]: Aggregations data.
    """
    return elastic_results.get("aggregations", elastic_results.get("aggs", {}))

def run_query_agent(question: str) -> Dict[str, Any]:
    """
    Run the query agent to retrieve and summarize data.

    Args:
        question (str): The user question.

    Returns:
        Dict[str, Any]: The summarized response.
    """
    try:
        elastic_results = elastic_retrieve(question)
        sources = extract_elastic_sources(elastic_results)
        aggregations = extract_aggregations(elastic_results)

        messages = [
            {"role": "system", "content": SUMMARIZER_PROMPT},
            {"role": "user", "content": f"Sources: {sources}\nAggregations: {aggregations}"},
        ]

        summary = get_chat_completion(messages)
        return {"summary": summary, "sources": sources, "aggregations": aggregations}
    except Exception as e:
        print(f"Error in run_query_agent: {e}")
        return {"error": str(e)}
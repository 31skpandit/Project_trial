from typing import Any, Dict, Optional
import redis
from app.config import settings
from app.core.logger import get_logger

logger = get_logger(__name__)

redis_client = None

if settings.CACHE_ENABLED:
    try:
        redis_client = redis.Redis(
            host=settings.REDIS_HOST,
            port=settings.REDIS_PORT,
            password=settings.REDIS_PASSWORD or None,
            decode_responses=True,
        )
        logger.info("Redis client initialized successfully.")
    except Exception as e:
        logger.error(f"Error initializing Redis client: {e}")

def create_cache_key(question: str, route: str) -> str:
    """
    Create a cache key based on the question and route.

    Args:
        question (str): The user question.
        route (str): The route.

    Returns:
        str: The generated cache key.
    """
    return f"{route}:{hash(question)}"

def get_from_cache(question: str, route: str) -> Optional[Dict[str, Any]]:
    """
    Retrieve a value from the cache.

    Args:
        question (str): The user question.
        route (str): The route.

    Returns:
        Optional[Dict[str, Any]]: The cached value, or None if not found.
    """
    if not redis_client:
        logger.warning("Redis client is not initialized.")
        return None

    try:
        key = create_cache_key(question, route)
        value = redis_client.get(key)
        return value if value else None
    except Exception as e:
        logger.error(f"Error retrieving from cache: {e}")
        return None

def set_to_cache(
    question: str,
    route: str,
    value: Dict[str, Any],
    ttl_seconds: int = 3600,
) -> bool:
    """
    Set a value in the cache.

    Args:
        question (str): The user question.
        route (str): The route.
        value (Dict[str, Any]): The value to cache.
        ttl_seconds (int): Time-to-live for the cache entry.

    Returns:
        bool: True if the value was set successfully, False otherwise.
    """
    if not redis_client:
        logger.warning("Redis client is not initialized.")
        return False

    try:
        key = create_cache_key(question, route)
        redis_client.setex(key, ttl_seconds, value)
        logger.info(f"Value cached for key: {key}")
        return True
    except Exception as e:
        logger.error(f"Error setting value to cache: {e}")
        return False
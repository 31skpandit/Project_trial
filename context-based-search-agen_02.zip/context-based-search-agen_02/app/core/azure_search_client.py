from typing import Any, Dict, List
from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient
from azure.search.documents.models import VectorizedQuery
from app.config import settings

# Initialize the Azure Search client
search_client = SearchClient(
    endpoint=settings.AZURE_SEARCH_ENDPOINT,
    index_name=settings.AZURE_SEARCH_INDEX_NAME,
    credential=AzureKeyCredential(settings.AZURE_SEARCH_KEY),
)

def keyword_search_documents(search_text: str, top: int = 5) -> List[Dict[str, Any]]:
    """
    Perform a keyword search on Azure Search.

    Args:
        search_text (str): The text to search for.
        top (int): The number of top results to return.

    Returns:
        List[Dict[str, Any]]: List of search results.
    """
    try:
        results = search_client.search(search_text, top=top)
        return [result for result in results]
    except Exception as e:
        print(f"Error in keyword_search_documents: {e}")
        return []
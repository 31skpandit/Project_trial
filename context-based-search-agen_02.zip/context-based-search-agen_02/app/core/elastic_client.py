from typing import Dict, Any
from elasticsearch import Elasticsearch
from app.config import settings
from app.core.logger import get_logger

logger = get_logger(__name__)

# Initialize Elasticsearch client
elastic_client = Elasticsearch(
    cloud_id=settings.ELASTIC_CLOUD_ID,
    api_key=settings.ELASTIC_API_KEY,
)

def ping_elastic() -> bool:
    """
    Check if Elasticsearch is reachable.

    Returns:
        bool: True if Elasticsearch is reachable, False otherwise.
    """
    try:
        return elastic_client.ping()
    except Exception as e:
        logger.error(f"Error pinging Elasticsearch: {e}")
        return False

def search_elastic(query_body: Dict[str, Any]) -> Dict[str, Any]:
    """
    Perform a search query on Elasticsearch.

    Args:
        query_body (Dict[str, Any]): The query body.

    Returns:
        Dict[str, Any]: The search results.
    """
    try:
        return elastic_client.search(
            index=settings.ELASTIC_INDEX_NAME,
            body=query_body,
        )
    except Exception as e:
        logger.error(f"Error in search_elastic: {e}")
        return {}

def index_document_to_elastic(document_id: str, document: Dict[str, Any]) -> Dict[str, Any]:
    """
    Index a document into Elasticsearch.

    Args:
        document_id (str): The document ID.
        document (Dict[str, Any]): The document to index.

    Returns:
        Dict[str, Any]: The indexing result.
    """
    try:
        return elastic_client.index(
            index=settings.ELASTIC_INDEX_NAME,
            id=document_id,
            document=document,
        )
    except Exception as e:
        logger.error(f"Error indexing document {document_id} to Elasticsearch: {e}")
        return {}

def create_elastic_index_if_not_exists(mapping: Dict[str, Any]) -> Dict[str, Any]:
    """
    Create an Elasticsearch index if it does not exist.

    Args:
        mapping (Dict[str, Any]): The index mapping.

    Returns:
        Dict[str, Any]: The result of the index creation.
    """
    try:
        if not elastic_client.indices.exists(index=settings.ELASTIC_INDEX_NAME):
            return elastic_client.indices.create(
                index=settings.ELASTIC_INDEX_NAME,
                body=mapping,
            )
        logger.info(f"Index {settings.ELASTIC_INDEX_NAME} already exists.")
        return {"acknowledged": True}
    except Exception as e:
        logger.error(f"Error creating Elasticsearch index: {e}")
        return {}
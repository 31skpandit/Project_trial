from typing import List, Dict
from openai import AzureOpenAI
from app.config import settings

# Initialize the Azure OpenAI client
client = AzureOpenAI(
    azure_endpoint=settings.AZURE_OPENAI_ENDPOINT,
    api_key=settings.AZURE_OPENAI_API_KEY,
    api_version=settings.AZURE_OPENAI_API_VERSION,
)

def get_chat_completion(
    messages: List[Dict[str, str]],
    temperature: float = 0.0,
    max_tokens: int = 1200,
) -> str:
    """
    Generate a chat completion using Azure OpenAI.

    Args:
        messages (List[Dict[str, str]]): List of message dictionaries for the chat.
        temperature (float): Sampling temperature for the model.
        max_tokens (int): Maximum number of tokens to generate.

    Returns:
        str: The content of the generated message.
    """
    try:
        response = client.chat.completions.create(
            model=settings.AZURE_OPENAI_CHAT_DEPLOYMENT,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
        )
        return response.choices[0].message.content or ""
    except Exception as e:
        # Log the error and return an empty string
        print(f"Error in get_chat_completion: {e}")
        return ""

def get_embedding(text: str) -> List[float]:
    """
    Generate an embedding for the given text using Azure OpenAI.

    Args:
        text (str): The input text to generate the embedding for.

    Returns:
        List[float]: The embedding vector for the input text.
    """
    try:
        response = client.embeddings.create(
            model=settings.AZURE_OPENAI_EMBEDDING_DEPLOYMENT,
            input=text,
        )
        return response.data[0].embedding
    except Exception as e:
        # Log the error and return an empty list
        print(f"Error in get_embedding: {e}")
        return []
    

#----------------- ok -----------------#
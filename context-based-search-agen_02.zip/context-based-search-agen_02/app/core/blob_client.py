from azure.storage.blob import BlobServiceClient
from app.config import settings

def upload_text_to_blob(blob_name: str, text: str) -> str:
    """
    Upload text to an Azure Blob.

    Args:
        blob_name (str): The name of the blob.
        text (str): The text content to upload.

    Returns:
        str: The URL of the uploaded blob.
    """
    blob_service_client = BlobServiceClient.from_connection_string(
        settings.AZURE_STORAGE_CONNECTION_STRING
    )

    container_client = blob_service_client.get_container_client(
        settings.AZURE_STORAGE_CONTAINER_NAME
    )

    try:
        container_client.create_container()
    except Exception as e:
        print(f"Container creation failed: {e}")

    try:
        blob_client = container_client.get_blob_client(blob_name)
        blob_client.upload_blob(text.encode("utf-8"), overwrite=True)
        return blob_client.url
    except Exception as e:
        print(f"Blob upload failed: {e}")
        return ""